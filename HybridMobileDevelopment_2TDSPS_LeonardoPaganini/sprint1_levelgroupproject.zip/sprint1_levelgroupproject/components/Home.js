import {View, Text, Image, ImageBackground, Pressable, SafeAreaView, StyleSheet} from 'react-native';


export default function Home(){
  return(
    <SafeAreaView style={styles.container}>
        <ImageBackground style={styles.backgroundImage} 
          source={require('./Media/background_plane.v3.png')}>
          <View style={styles.navbar}>
            <Image style={styles.logo} source={'./Media/logo_navbar.png'}/>
          </View>
          <View style={styles.containerText}>
            <Text style={styles.text1}>
              BUY SMARTER.
            </Text>
            <Text style={styles.text2}>
              SELL FASTER.
            </Text>
            <Text style={styles.text3}>
              Conecte-se à maior rede mundial de peças e serviços de aviação
            </Text>
          </View>
          <Pressable style={styles.button} title="FAÇA PARTE!">
            <Text style={styles.textButton}>FAÇA PARTE</Text>
          </Pressable>
        </ImageBackground>
    </SafeAreaView>
  )
}
const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  backgroundImage: {
    flex: 1,
    justifyContent: 'center',
    resizeMode: 'cover',
    height: 800,
    zIndex: -1
  },
  navbar:{
    color: 'black',
    width: 200,
    height: 84,
  },
  logo:{
    
  },
  containerText:{
    paddingTop: 280,
    alignItems: 'center',
    justifyContent: 'center'
  },
  text1:{
    fontWeight: 'bold',
    fontSize: 40,
    color: '#466FC7',
    marginBottom: 10,
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: {width: -2, height: 2},
    textShadowRadius: 4
  },
  text2: {
    paddingTop: 10,
    fontWeight: 'bold',
    fontSize: 40,
    color: '#FFF',
    marginBottom: 10,
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: {width: -2, height: 2},
    textShadowRadius: 4
  },
  text3:{
    fontSize: 30,
    marginBottom: 10,
    textAlign: 'center',
    color: '#FFF'
  },
  button:{
    marginTop: 20,
    marginLeft: 120,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#B8CAD6',
    borderRadius: 47,
    width: 160,
    height: 60,
    color: '#FFF',
    shadowOffset: {width: -4, height: 4},  
    shadowColor: 'rgba(0, 0, 0, 5)',  
    shadowOpacity: 0.4,  
    shadowRadius: 5,  
  },
  textButton:{
    fontSize: 24,
    lineHeight: 28,
    color: '#285FDB',
    fontWeight: 'bold',
  }
})